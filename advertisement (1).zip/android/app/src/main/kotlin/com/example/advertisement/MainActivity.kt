package com.example.advertisement

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
